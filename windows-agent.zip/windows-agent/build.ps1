# PrintOps Agent Build Script
# Builds the Windows Service agent and optional MSI installer

param(
    [switch]$Installer,
    [switch]$Clean
)

$ErrorActionPreference = "Stop"

Write-Host "========================================" -ForegroundColor Cyan
Write-Host "  PrintOps Agent Build Script" -ForegroundColor Cyan
Write-Host "========================================" -ForegroundColor Cyan

$AgentPath = Join-Path $PSScriptRoot "PrintOpsAgent"
$InstallerPath = Join-Path $PSScriptRoot "PrintOpsAgent.Installer"
$OutputPath = Join-Path $PSScriptRoot "bin"

if ($Clean) {
    Write-Host "`nCleaning build directories..." -ForegroundColor Yellow
    Remove-Item -Recurse -Force (Join-Path $AgentPath "bin") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $AgentPath "obj") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $InstallerPath "bin") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force (Join-Path $InstallerPath "obj") -ErrorAction SilentlyContinue
    Remove-Item -Recurse -Force $OutputPath -ErrorAction SilentlyContinue
}

# Create output directory
New-Item -ItemType Directory -Force -Path $OutputPath | Out-Null

# Build agent
Write-Host "`n[1/3] Building PrintOps Agent..." -ForegroundColor Green
Push-Location $AgentPath
try {
    dotnet publish -c Release -r win-x64 --self-contained true /p:PublishSingleFile=true -o $OutputPath
    if ($LASTEXITCODE -ne 0) { throw "Agent build failed" }
    Write-Host "  Agent built successfully!" -ForegroundColor Green
}
finally {
    Pop-Location
}

# Build installer if requested
if ($Installer) {
    Write-Host "`n[2/3] Building MSI Installer..." -ForegroundColor Green
    
    # Check for WiX
    $wixPath = Get-Command dotnet-wix -ErrorAction SilentlyContinue
    if (-not $wixPath) {
        Write-Host "  Installing WiX Toolset..." -ForegroundColor Yellow
        dotnet tool install --global wix
    }
    
    Push-Location $InstallerPath
    try {
        dotnet build -c Release -o $OutputPath
        if ($LASTEXITCODE -ne 0) { throw "Installer build failed" }
        Write-Host "  Installer built successfully!" -ForegroundColor Green
    }
    finally {
        Pop-Location
    }
}
else {
    Write-Host "`n[2/3] Skipping MSI Installer (use -Installer flag to build)" -ForegroundColor Yellow
}

# Summary
Write-Host "`n[3/3] Build Complete!" -ForegroundColor Green
Write-Host "========================================" -ForegroundColor Cyan
Write-Host "Output files:"
Get-ChildItem $OutputPath | ForEach-Object {
    Write-Host "  $($_.Name)" -ForegroundColor White
}

Write-Host "`n Installation Instructions:" -ForegroundColor Yellow
Write-Host "  1. Copy PrintOpsAgent.exe to target Windows machine"
Write-Host "  2. Run as Administrator: sc create PrintOpsAgent binPath= `"C:\path\to\PrintOpsAgent.exe`" start= auto"
Write-Host "  3. Configure: C:\ProgramData\PrintOps\config.json"
Write-Host "  4. Start service: sc start PrintOpsAgent"
Write-Host ""
